<?php


// $cardlists = parent::getCustomerCardlist();
echo "<pre>";print_r($cardlists);echo "</pre>";
?>